Action() {

	web_url("www.example.com",
	    "URL=http://www.example.com",
	    "Snapshot=t10.inf",
	    LAST);

    web_url("www.example.com",
	    "URL=http://www.example.com",
	    "Snapshot=t20.inf",
	    LAST);

    web_url("www.example.com",
	    "URL=http://www.example.com",
	    "Snapshot=t30.inf",
	    LAST);


	return 0;
}
